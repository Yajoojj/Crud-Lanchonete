<?php

$conexao = mysqli_connect("localhost", "root", "", "lanchonete");
mysqli_set_charset($conexao, "utf8");

?>