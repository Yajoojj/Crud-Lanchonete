<!DOCTYPE html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
   <!--MENU-->
   <?php   include '../componentes/menu.php'; ?>
    <!--------------------------------->  
   
   
   <?php

include '../php/conexao.php';

$sql = "SELECT * FROM funcionarios";

$resultado = mysqli_query($conexao, $sql);

echo "<table width='500' border='1px'>
<tr>
   <th>ID</th>
   <th>Nome</th>
   <th>CPF</th>
   <th>Telefone</th>
   <th>Endereço</th>
   <td>Ação</td>
   ";

while($linha = mysqli_fetch_assoc($resultado)){
    echo "<tr>
     <td>".$linha ['id_funcionario']."</td> 
     <td>".$linha ['nome_funcionario']."</td>
     <td>".$linha ['cpf_funcionario']."</td>
     <td>".$linha ['telefone_funcionario']."</td>
     <td>".$linha ['endereco_funcionario']."</td>
     <td>
     <a href='cadFunc.php?acao=editar&id={$linha['id_funcionario']}'>Editar</a> - 

     <a href='../php/procFunc.php?acao=excluir&id=".$linha['id_funcionario']."'>Excluir</a></td>
     
     </tr>
     "
     ; 
}

echo "</table>";
?>
   
</body>
</html>

